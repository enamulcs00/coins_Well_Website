import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-chatscreen',
  templateUrl: './chatscreen.component.html',
  styleUrls: ['./chatscreen.component.scss']
})
export class ChatscreenComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
