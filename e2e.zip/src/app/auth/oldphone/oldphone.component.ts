import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-oldphone',
  templateUrl: './oldphone.component.html',
  styleUrls: ['./oldphone.component.scss']
})
export class OldphoneComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
