import { Component, OnInit } from '@angular/core';
import { MatDialogRef } from '@angular/material/dialog';
@Component({
  selector: 'app-signup-activate',
  templateUrl: './signup-activate.component.html',
  styleUrls: ['./signup-activate.component.scss']
})
export class SignupActivateComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }
  // SetupPasswordDialog(){
  //   this.dialog.close();
  //   this.authModalService.SetupPasswordDialog();
  // }
}


