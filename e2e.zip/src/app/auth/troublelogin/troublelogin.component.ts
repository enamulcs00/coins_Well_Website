import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-troublelogin',
  templateUrl: './troublelogin.component.html',
  styleUrls: ['./troublelogin.component.scss']
})
export class TroubleloginComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
