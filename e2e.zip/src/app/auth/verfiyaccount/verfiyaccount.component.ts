import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-verfiyaccount',
  templateUrl: './verfiyaccount.component.html',
  styleUrls: ['./verfiyaccount.component.scss']
})
export class VerfiyaccountComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
