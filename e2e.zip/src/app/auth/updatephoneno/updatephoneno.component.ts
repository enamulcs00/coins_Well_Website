import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-updatephoneno',
  templateUrl: './updatephoneno.component.html',
  styleUrls: ['./updatephoneno.component.scss']
})
export class UpdatephonenoComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
