import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-createprofile',
  templateUrl: './createprofile.component.html',
  styleUrls: ['./createprofile.component.scss']
})
export class CreateprofileComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
