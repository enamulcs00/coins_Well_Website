import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-transactionpin',
  templateUrl: './transactionpin.component.html',
  styleUrls: ['./transactionpin.component.scss']
})
export class TransactionpinComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
