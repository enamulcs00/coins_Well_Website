import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-verify-doc',
  templateUrl: './verify-doc.component.html',
  styleUrls: ['./verify-doc.component.scss']
})
export class VerifyDocComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
