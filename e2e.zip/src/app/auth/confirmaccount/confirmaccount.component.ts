import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-confirmaccount',
  templateUrl: './confirmaccount.component.html',
  styleUrls: ['./confirmaccount.component.scss']
})
export class ConfirmaccountComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
