import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-addbankdetails',
  templateUrl: './addbankdetails.component.html',
  styleUrls: ['./addbankdetails.component.scss']
})
export class AddbankdetailsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
