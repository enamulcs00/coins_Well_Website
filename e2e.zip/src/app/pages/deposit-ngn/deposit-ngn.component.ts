import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-deposit-ngn',
  templateUrl: './deposit-ngn.component.html',
  styleUrls: ['./deposit-ngn.component.scss']
})
export class DepositNgnComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
