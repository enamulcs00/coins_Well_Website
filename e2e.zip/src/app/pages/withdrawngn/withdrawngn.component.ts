import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-withdrawngn',
  templateUrl: './withdrawngn.component.html',
  styleUrls: ['./withdrawngn.component.scss']
})
export class WithdrawngnComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
