import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-change-transtionpin',
  templateUrl: './change-transtionpin.component.html',
  styleUrls: ['./change-transtionpin.component.scss']
})
export class ChangeTranstionpinComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
