import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-verifyphonenumber',
  templateUrl: './verifyphonenumber.component.html',
  styleUrls: ['./verifyphonenumber.component.scss']
})
export class VerifyphonenumberComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
