import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-withdrawcrypto',
  templateUrl: './withdrawcrypto.component.html',
  styleUrls: ['./withdrawcrypto.component.scss']
})
export class WithdrawcryptoComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
