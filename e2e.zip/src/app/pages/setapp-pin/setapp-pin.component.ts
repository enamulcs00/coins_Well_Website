import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-setapp-pin',
  templateUrl: './setapp-pin.component.html',
  styleUrls: ['./setapp-pin.component.scss']
})
export class SetappPinComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
