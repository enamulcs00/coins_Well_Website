import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-emailverify',
  templateUrl: './emailverify.component.html',
  styleUrls: ['./emailverify.component.scss']
})
export class EmailverifyComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
