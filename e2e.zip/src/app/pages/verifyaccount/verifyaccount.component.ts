import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-verifyaccount',
  templateUrl: './verifyaccount.component.html',
  styleUrls: ['./verifyaccount.component.scss']
})
export class VerifyaccountComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
