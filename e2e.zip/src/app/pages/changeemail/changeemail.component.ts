import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-changeemail',
  templateUrl: './changeemail.component.html',
  styleUrls: ['./changeemail.component.scss']
})
export class ChangeemailComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
