import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mydetails',
  templateUrl: './mydetails.component.html',
  styleUrls: ['./mydetails.component.scss']
})
export class MydetailsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
