import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-account-upgrade',
  templateUrl: './account-upgrade.component.html',
  styleUrls: ['./account-upgrade.component.scss']
})
export class AccountUpgradeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
